"""
Simple Example
==============

Test
"""

import matplotlib.pyplot as plt
import helper

plt.plot(helper.x, helper.y)

plt.show()
